async function printElement(printValue) {
  const printData = JSON.parse(printValue);
  let renderHTML = '';
  _.map(printData, (item) => {
    const countRows = item.banIn > 3 ? _.ceil(item.banIn / 3) : 1;
    for (let i = 0; i < countRows; i++) {
      const ngaySanXuat = item.ngaySanXuat ? `NSX: ${item.ngaySanXuat}` : '';
      const soLuong = item.soLuong && item.soLuong > 1 ? `SL: ${item.soLuong} ${item.donViTinh}` : '';
      let renderItem = '';
      let totalRenderItem = (i === countRows - 1 && item.banIn % 3 !== 0) ? 3 - (countRows * 3 - item.banIn) : 3;
      if (countRows === 1 && item.banIn % 3 !== 0) totalRenderItem = item.banIn;
      for (let y = 0; y < 3; y++) {
        if (y >= totalRenderItem) {
          renderItem += `
          <!-- Item QR -->
          <div style="height:1.2in !important; line-height: 1.2in; margin-right: 0.118in; margin-left: 0.118in;" class="sticker-border"></div>
          <!-- End Item QR -->
        `;
        } else {
          renderItem += `
        <!-- Item QR -->
        <div style="height:1.2in !important; line-height: 1.2in; margin-right: 0.118in; margin-left: 0.118in;" class="sticker-border">
          <div style="display:flex;line-height:16px !important;flex: 1;flex-direction: column;">
            <div style="display: flex; flex: 1; flex-direction: row;">
              <div class="th-qr-image">
                <img style="height: 40px;width: 40px; margin-right: 3px;"
                  src="${item.image}">
              </div>
              <div>
                <div id="th-qr-nsx" style="font-weight: bold;font-size: 12px;">
                  <span>${ngaySanXuat}</span>
                </div>
                <div class="th-qr-sl" style="flex: 10">
                  <span style="font-size: 12px;font-weight: bold;">${soLuong}</span>
                </div>
              </div>
            </div>
            <div style="display: flex; flex-direction: column; margin-top: 2px;">
              <div class="th-qr-mavt" style="font-size: 12px;">
                <span><strong>${item.maVatTu}</strong></span>
              </div>
              <div class="th-qr-tenvt" style="font-size: 12px;">
                <span style="line-height: 1;">${item.tenVatTu}</span>
              </div>
            </div>
          </div>
        </div>
        <!-- End Item QR -->
        `;
        }
      }
      renderHTML += `
      <!-- 3 Items -->
      <div style="display: grid; grid-template-columns: 1.75in 1.75in 1.75in; margin-left: 0 !important;">
        ${renderItem}
      </div>
      <!-- End 3 Item -->
      <div class="break-page"></div>
      `;
      // if (i !== countRows - 1) renderHTML += ``;
    }
  });

  // Grab an element
  const qrWrapper = await document.getElementById('qr-print-wrapper'),
    // Make a new div
    elChild = document.createElement('div');
  // Give the new div some content
  elChild.innerHTML = renderHTML;
  // Jug it into the parent element
  await qrWrapper.appendChild(elChild);
  window.print();
  window.onafterprint = function () {
    window.close();
  }
}

// Action
// Check lodash isWorking ?
document.onreadystatechange = function () {
  if (_) {
    var printValue = window.localStorage.getItem('inTemValue');
    if (!_.isEmpty(printValue)) {
      printElement(printValue);
    }
  } else {
    alert('Lỗi không thể tải thư viện. Vui lòng kiểm tra kết nối mạng.');
  }
};
